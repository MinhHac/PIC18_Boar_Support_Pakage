// SLAVE

/** I N C L U D E S **********************************************************/
#include <p18f4550.h>
#include <spi.h>
#include <adc.h>

/** V E C T O R  R E M A P P I N G *******************************************/
//
//extern void _startup (void);        // See c018i.c in your C18 compiler dir
////#pragma code _RESET_INTERRUPT_VECTOR = 0x000800
//void _reset (void)
//{    _asm goto _startup _endasm
//}
//#pragma code

/** D E C L A R A T I O N S **************************************************/
#pragma code

/******************************************************************************
 * Function:        void main(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        Main program entry point.
 *
 * Note:            None
 *****************************************************************************/
	int Data, result;
	int i, j, done;
	int convert_adc();
static void InitializeSystem(void);
void main(void)
{
	int receivedData;
	int i, j, done;
	
	InitializeSystem();

	
// Set CS pin (RB2), for the TC77 temperature chip on the PICDEM, as output
	TRISBbits.TRISB2 = 0;

	// Deselect the TC77
	PORTBbits.RB2 = 1; 
	
	// Initialization of SS (Slave Select), RA5 happens in OpenSPI
	// Enables (SSPEN) the SPI port at the end of OpenSPI
    OpenSPI(SLV_SSON, MODE_00, SMPMID);

	TRISA = 0x21; // This seems to work... WHY? This would appear to be RA4 not RA5.

	// Sign of life
//	PORTDbits.RD0 = 1;

	for (;;) {	
			convert_adc();
				PORTD = result>>6;

			SSPCON1bits.WCOL = 0;
			SSPBUF = PORTD;                // write byte to SSPBUF register
   			while(SSPCON1bits.WCOL){    // test if write collision occurred
       		SSPCON1bits.WCOL = 0;
       		SSPBUF = PORTD;     
      } // write byte to SSPBUF register
		
			// Write collision occurred
		//	PORTDbits.RD1 = ~PORTDbits.RD1;
		// Sign of life
		//	PORTDbits.RD0 = ~PORTDbits.RD0;
	}
}//end main


#define mInitAllLEDs()      LATD &= 0xF0; TRISD &= 0xF0;

static void InitializeSystem(void)
{
    ADCON1 |= 0x0E;                 // Default all pins to digital

	mInitAllLEDs();

}//end InitializeSystem

/** EOF main.c ***************************************************************/



int convert_adc()
{
	
	OpenADC(ADC_FOSC_32 & 
		ADC_RIGHT_JUST & 
		ADC_12_TAD, 
		ADC_CH0 &  			//CHANGE CHANNEL ACCORDINGLY
		ADC_INT_OFF, 15);
	
	Delay10TCYx(5);		// delay for 50tcy
	SetChanADC(ADC_CH0);
	ConvertADC(); 			// start conversion
	while(BusyADC()); 	// wait for completion
	result = ReadADC(); 	// read result
}